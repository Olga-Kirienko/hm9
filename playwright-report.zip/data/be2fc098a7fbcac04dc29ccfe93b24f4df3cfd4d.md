# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: disappear.spec.ts >> test
- Location: hm11/disappear.spec.ts:3:5

# Error details

```
Error: browserType.launch: Failed to launch the browser process.
Browser logs:

╔════════════════════════════════════════════════════════════════════════════════════════════════╗
║ Looks like you launched a headed browser without having a XServer running.                     ║
║ Set either 'headless: true' or use 'xvfb-run <your-playwright-app>' before running Playwright. ║
║                                                                                                ║
║ <3 Playwright Team                                                                             ║
╚════════════════════════════════════════════════════════════════════════════════════════════════╝
Call log:
  - <launching> /home/runner/.cache/ms-playwright/firefox-1532/firefox/firefox -no-remote -wait-for-browser -foreground -profile /tmp/playwright_firefoxdev_profile-qwYJWG -juggler-pipe -silent
  - <launched> pid=5508
  - [pid=5508][err] [5510] Sandbox: CanCreateUserNamespace() unshare(CLONE_NEWPID): EPERM
  - [pid=5508][err] Error: no DISPLAY environment variable specified
  - [pid=5508] <process did exit: exitCode=1, signal=null>
  - [pid=5508] starting temporary directories cleanup
  - [pid=5508] <gracefully close start>
  - [pid=5508] <kill>
  - [pid=5508] <skipped force kill spawnedProcess.killed=false processClosed=true>
  - [pid=5508] finished temporary directories cleanup
  - [pid=5508] <gracefully close end>

```